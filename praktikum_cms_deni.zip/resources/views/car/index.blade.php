@extends('layouts.app')

@section('content')
    <h1>Daftar Mobil Tersedia</h1>

    @if($cars->count())
        <ul>
            @foreach($cars as $car)
                <li>
                    <strong>{{ $car->nama_mobil }}</strong> - 
                    {{ $car->jenis_mobil }} | 
                    {{ $car->kategori->nama ?? 'Kategori Kosong' }} | 
                    {{ $car->transmisi }} | 
                    Rp {{ number_format($car->harga_sewa_per_hari, 0, ',', '.') }}
                </li>
            @endforeach
        </ul>
    @else
        <p>Tidak ada mobil yang tersedia.</p>
    @endif
@endsection
