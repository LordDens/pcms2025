<!-- NAVIGATION -->
<nav id="navigation">
    <!-- container -->
    <div class="container">
        <!-- responsive-nav -->
        <div id="responsive-nav">
            <!-- NAV -->
            <ul class="main-nav nav navbar-nav">
                <li class="active"><a href="{{ url('/') }}">Beranda</a></li>
                <li><a href="{{ route('rents.index') }}">Data Sewa</a></li>
                <li><a href="{{ route('car.create') }}">Mobil</a></li>
                <li><a href="#">Laporan</a></li>
                <li><a href="#">Kontak</a></li>
            </ul>
            <!-- /NAV -->
        </div>
        <!-- /responsive-nav -->
    </div>
    <!-- /container -->
</nav>
<!-- /NAVIGATION -->
