<?php

namespace App\Http\Controllers;

use App\Models\Car;
use App\Models\Kategori;
use Illuminate\Http\Request;

class CarController extends Controller
{
    public function create()
    {
        $kategoris = Kategori::all();
        return view('car.create', compact('kategoris'));
    }
    

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_mobil' => 'required|string',
            'jenis_mobil' => 'required|string',
            'kategori_id' => 'required|exists:kategoris,id',
            'transmisi' => 'required|in:Manual,Matic',
            'ready' => 'required|boolean',
            'harga_sewa_per_hari' => 'required|numeric',
        ]);

        Car::create($validated);

        return redirect()->route('car.index')->with('success', 'Mobil berhasil ditambahkan.');
    }

    public function index()
    {
    $cars = Car::where('ready', 1)->with('kategori')->get();
    return view('car.index', compact('cars'));
    }
}
