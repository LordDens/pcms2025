

<?php $__env->startSection('content'); ?>
    <h1>Daftar Mobil Tersedia</h1>

    <?php if($cars->count()): ?>
        <ul>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <strong><?php echo e($car->nama_mobil); ?></strong> - 
                    <?php echo e($car->jenis_mobil); ?> | 
                    <?php echo e($car->kategori->nama ?? 'Kategori Kosong'); ?> | 
                    <?php echo e($car->transmisi); ?> | 
                    Rp <?php echo e(number_format($car->harga_sewa_per_hari, 0, ',', '.')); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
        <p>Tidak ada mobil yang tersedia.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\praktikum\praktikum_cms_deni\resources\views/car/index.blade.php ENDPATH**/ ?>