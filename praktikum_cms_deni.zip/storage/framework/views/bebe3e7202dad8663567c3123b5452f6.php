<!-- NAVIGATION -->
<nav id="navigation">
    <!-- container -->
    <div class="container">
        <!-- responsive-nav -->
        <div id="responsive-nav">
            <!-- NAV -->
            <ul class="main-nav nav navbar-nav">
                <li class="active"><a href="<?php echo e(url('/')); ?>">Beranda</a></li>
                <li><a href="<?php echo e(route('rents.index')); ?>">Data Sewa</a></li>
                <li><a href="<?php echo e(route('car.create')); ?>">Mobil</a></li>
                <li><a href="#">Laporan</a></li>
                <li><a href="#">Kontak</a></li>
            </ul>
            <!-- /NAV -->
        </div>
        <!-- /responsive-nav -->
    </div>
    <!-- /container -->
</nav>
<!-- /NAVIGATION -->
<?php /**PATH C:\xampp\praktikum\praktikum_cms_deni\resources\views/partials/navigation.blade.php ENDPATH**/ ?>