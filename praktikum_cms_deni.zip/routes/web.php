<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CarController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', [CarController::class, 'index'])->name('home');



// Halaman utama menampilkan daftar mobil untuk umum (tanpa login)
Route::get('/', [CarController::class, 'index'])->name('home');

// Dashboard (hanya setelah login & verifikasi)
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// Group route untuk user yang sudah login
Route::middleware('auth')->group(function () {
    // Profil
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Hanya admin yang seharusnya bisa tambah mobil
    Route::get('/car/create', [CarController::class, 'create'])->name('car.create');
    Route::post('/car', [CarController::class, 'store'])->name('car.store');
});

// Route tambahan untuk melihat daftar mobil (bisa tanpa login)
Route::get('/car', [CarController::class, 'index'])->name('car.index');

require __DIR__.'/auth.php';
